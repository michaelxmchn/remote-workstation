# 🔥 Clash Verge VPN 配置 (Ubuntu)
# 用于另一台 Ubuntu 电脑翻墙

## 订阅地址

**主订阅地址 (重要!)**:
```
https://c19808d1e81a2cb012471e4c4f189436.r7kq-2nfa-hg9x-bt4m-y3pw.sbs/s?t=c19808d1e81a2cb012471e4c4f189436.jpg
```

## 安装步骤

### 方法 1: 一键安装 (推荐)
```bash
# 插上 U 盘后，复制整个 vpn-ubuntu 文件夹到新电脑
cd /path/to/usb/vpn-ubuntu
chmod +x install.sh
./install.sh
```

### 方法 2: 手动安装
```bash
# 1. 下载 Clash Verge
wget https://github.com/clash-verge-rev/clash-verge-rev/releases/download/v1.7.1/Clash-Verge_v1.7.1_amd64.deb

# 2. 安装
sudo dpkg -i Clash-Verge_v1.7.1_amd64.deb
sudo apt-get install -f -y

# 3. 打开应用，添加订阅
# 复制上面的订阅地址，粘贴到"订阅"输入框
# 点击"更新"
```

## 使用方法

1. 打开 Clash Verge
2. 点击左侧 "Profiles(配置)"
3. 点击 "+" 添加订阅
4. 粘贴订阅地址
5. 点击 "Update(更新)"
6. 在 "Proxies(代理)" 选择节点
7. 点击 "Enable(启用)"

## 流量信息

- 已用: 167.3 GB / 300 GB
- 过期: 2025-02-18
- 上传: 2.5 GB

## 常见问题

Q: 连接不上?
A: 检查订阅是否更新，尝试切换节点

Q: 速度慢?
A: 尝试其他节点，或检查本地网络

Q: 如何更新订阅?
A: 右键点击配置 -> Reload

---
