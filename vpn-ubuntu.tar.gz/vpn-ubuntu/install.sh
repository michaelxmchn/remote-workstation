#!/bin/bash
# Clash Verge 安装脚本 (从网上下载)
# 如果 U 盘里没有 .deb 文件，会自动下载

set -e

DEB_FILE="Clash-Verge_v1.7.1_amd64.deb"
URLS=(
  "https://github.com/clash-verge-rev/clash-verge-rev/releases/download/v1.7.1/Clash-Verge_v1.7.1_amd64.deb"
  "https://ghproxy.com/https://github.com/clash-verge-rev/clash-verge-rev/releases/download/v1.7.1/Clash-Verge_v1.7.1_amd64.deb"
)

echo -e "${GREEN}[1/5] 检查本地安装包...${NC}"

if [ -f "$DEB_FILE" ]; then
    echo "找到本地安装包: $DEB_FILE"
else
    echo "本地没有安装包，尝试下载..."
    
    for url in "${URLS[@]}"; do
        echo "尝试: $url"
        if curl -L -o "$DEB_FILE" "$url" --connect-timeout 30 --max-time 120; then
            if [ -s "$DEB_FILE" ]; then
                echo "✅ 下载成功!"
                break
            fi
        fi
        echo "❌ 下载失败，尝试下一个..."
    done
    
    if [ ! -s "$DEB_FILE" ]; then
        echo -e "${RED}❌ 下载失败!${NC}"
        echo ""
        echo "请手动下载 Clash Verge:"
        echo "1. 打开: https://github.com/clash-verge-rev/clash-verge-rev/releases"
        echo "2. 下载: Clash-Verge_v1.7.1_amd64.deb"
        echo "3. 放到当前目录"
        echo "4. 重新运行: sudo ./install.sh"
        exit 1
    fi
fi

echo ""
echo -e "${GREEN}[2/5] 安装依赖...${NC}"
apt update
apt install -y wget gnome-terminal

echo ""
echo -e "${GREEN}[3/5] 安装 Clash Verge...${NC}"
dpkg -i $DEB_FILE || {
    echo -e "${YELLOW}修复依赖...${NC}"
    apt-get install -f -y
}

echo ""
echo -e "${GREEN}[4/5] 清理...${NC}"
# rm -f $DEB_FILE  # 可选：删除安装包节省空间

echo ""
echo -e "${GREEN}[5/5] 完成!${NC}"
echo ""
echo -e "${GREEN}✅ Clash Verge 安装成功!${NC}"
echo ""
echo -e "${YELLOW}下一步:${NC}"
echo "1. 在应用菜单中找到 Clash Verge 并打开"
echo "2. 点击左侧 'Profiles(配置)'"
echo "3. 点击 '+' 添加订阅"
echo "4. 粘贴订阅地址:"
echo ""
cat << 'EOF'
https://c19808d1e81a2cb012471e4c4f189436.r7kq-2nfa-hg9x-bt4m-y3pw.sbs/s?t=c19808d1e81a2cb012471e4c4f189436.jpg
EOF
echo ""
echo "5. 点击 'Update(更新)'"
echo "6. 在 'Proxies(代理)' 选择节点"
echo "7. 点击 'Enable(启用)'"
echo ""
echo -e "${GREEN}完成! 🎉${NC}"
